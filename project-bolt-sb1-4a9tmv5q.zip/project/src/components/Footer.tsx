import React from 'react';
import { Github, Linkedin, Mail, Heart } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-800 text-white py-12">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {/* About */}
            <div>
              <h3 className="text-2xl font-bold mb-4">J Sowmya Teja</h3>
              <p className="text-slate-300 leading-relaxed">
               
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-lg font-semibold mb-4"></h4>
              <div className="space-y-2">
                {['Home', 'About', 'Skills', 'Portfolio', 'Contact'].map((item) => (
                  <button
                    key={item}
                    onClick={() => {
                      const element = document.getElementById(item.toLowerCase());
                      if (element) {
                        element.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    className="block text-slate-300 hover:text-white transition-colors duration-200"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>

            {/* Contact Info */}
            <div>
              <h4 className="text-lg font-semibold mb-4"></h4>
              <div className="space-y-3">
                <a 
                  href="mailto:john.smith@email.com" 
                  className="flex items-center space-x-3 text-slate-300 hover:text-white transition-colors duration-200"
                >
                  <Mail size={18} />
                  <span>jittesowmyateja@gmail.com</span>
                </a>
                <p className="text-slate-300">Gollapally, Shamshabad, hyderabad</p>
              </div>
            </div>
          </div>

          {/* Bottom Section */}
          <div className="border-t border-slate-700 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-slate-300 text-center md:text-left mb-4 md:mb-0">
                © {currentYear} Jitte Sowmya Teja. <Heart className="inline text-red-500" size={16} /> 
               
              </p>
              
              <div className="flex space-x-6">
                <a 
                  href="#" 
                  className="text-slate-300 hover:text-white transition-colors duration-200 transform hover:scale-110"
                >
                  <Github size={24} />
                </a>
                <a 
                  href="#" 
                  className="text-slate-300 hover:text-white transition-colors duration-200 transform hover:scale-110"
                >
                  <Linkedin size={24} />
                </a>
                <a 
                  href="mailto:jittesowmyateja@gmail.com" 
                  className="text-slate-300 hover:text-white transition-colors duration-200 transform hover:scale-110"
                >
                  <Mail size={24} />
                </a>
              </div>
            </div>
          </div>

          {/* Back to Top Button */}
          <button
            onClick={scrollToTop}
            className="fixed bottom-8 right-8 bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-110 z-40"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
            </svg>
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;