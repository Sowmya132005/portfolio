import React from 'react';
import { ExternalLink, Github } from 'lucide-react';

const Portfolio = () => {
  const projects = [
    {
      title: "IOT Based Noise Detection and Alert System",
      description: "Designed an ESP32 based iot system to detect loud noises and visually alert deaf individuals using LED indicators. Integrated Twilio PI to send real time SMS alerts to caregivers for enhanced safety and emergency awareness.",
      liveUrl: "https://drive.google.com/file/d/1TPBkczoE5qzIJlO_DfjiNyVvPPk9uA8M/view",
      image: "",
      githubUrl: "",
      tags: []
    },
    {
      title: "Conducted security analysis and exploited vulnerabilities such as all types of xss",
      description: "",
      image: "",
      githubUrl: "",
      tags: [],
      liveUrl: ""
    },
    {
      title: "weather API",
      description: "Developed a responsive weather application that fetches and displays real-time temperature data based on user input. Integrated the WeatherAPI to retrieve live weather conditions, including temperature, location. Implemented with HTML, CSS, and JavaScript, the app allows users to search for any city and instantly view updated weather information.",
      image: "",
      githubUrl: "",
      tags: [],
      liveUrl: ""
    },

    {
      title: "Vulnerability Assessment",
      description: "Set up and configured windows virtual machine on virtual box. – Installed and configured Nessus vulnerability scanner on the windows VM. – Conducted comprehensive vulnerability scans using Nessus, including credential scans. -Identified and analyzed vulnerabilities in the system and installed vulnerable software foe testing purposes. – Developing and implemented effective remediation strategies to address identified vulnerabilities.",
      image: "",
      githubUrl: "",
      tags: [],
      liveUrl: ""

    },
    {
      title: "AI Chat Bot" ,
      description: "•	AI Powered Resume Analyzer serves as a virtual HR assistant providing: - Detailed resume evaluation, including strengths and weaknesses. – suggestions for skill improvement and recommended courses.",
      image: "",
      githubUrl: "",
      tags: [],
      liveUrl: ""
    }
  ];

  return (
    <section id="portfolio" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-slate-800 mb-16">
            Featured Projects
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden">
                <div className="relative group">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-300 flex items-center justify-center">
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex space-x-4">
                      <a 
                        href={project.liveUrl}
                        className="bg-white text-slate-800 p-3 rounded-full hover:bg-blue-600 hover:text-white transition-colors duration-200"
                      >
                        <ExternalLink size={20} />
                      </a>
                      <a 
                        href={project.githubUrl}
                        className="bg-white text-slate-800 p-3 rounded-full hover:bg-blue-600 hover:text-white transition-colors duration-200"
                      >
                        <Github size={20} />
                      </a>
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-slate-800 mb-3">
                    {project.title}
                  </h3>
                  <p className="text-slate-600 mb-4 leading-relaxed">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag, tagIndex) => (
                      <span 
                        key={tagIndex}
                        className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;