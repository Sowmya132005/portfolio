import React from 'react';
import { Code, Lightbulb, Users, Target } from 'lucide-react';

const About = () => {
  const highlights = [];


  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-slate-800 mb-16">
            About Me
          </h2>
          
          <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h3 className="text-2xl font-semibold text-slate-800 mb-6">

              </h3>
              <p className="text-lg text-slate-600 mb-6 leading-relaxed">
               I'm a 4th year student pursing B.tech in computer science and technology(IOT). I'm particularly interested in web technologies         and seeking for a internship opportunity where I can apply my skills, learn from real world challenges.
              </p>
              <p className="text-lg text-slate-600 mb-6 leading-relaxed">
              </p>
            </div>
            
            <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-8 rounded-2xl">

              <div className="space-y-6">
                {highlights.map((item, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="flex-shrink-0 p-2 bg-white rounded-lg shadow-sm">
                      {item.icon}
                    </div>
                    <div>
                      <h5 className="font-semibold text-slate-800 mb-1">{item.title}</h5>
                      <p className="text-sm text-slate-600">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;